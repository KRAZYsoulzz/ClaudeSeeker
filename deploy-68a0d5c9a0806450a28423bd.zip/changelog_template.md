# Changelog Template

## Version X.Y.Z (YYYY-MM-DD)
### UI
- Short bullet of a user-facing change
- Short bullet of another UI change

### Behavior / Data
- Brief line about backup/restore, data handling, or logic

### Fixes
- One-liner bug fix
