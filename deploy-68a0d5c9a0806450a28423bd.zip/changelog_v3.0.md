# Changelog — V3.0

## UI
- Inline button layout on the main card, aligned with the pill counter.
- Gold “+” vector icon; consistent button styling.
- Version badge shows a single, clean value.

## Backup & Restore
- JSON export/import with safe merge by date (add new days; update only if newer).
- Undo last import.
- Backup page cleaned up for clarity.
